package com.tutorial.eurekaservicie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaServicieApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServicieApplication.class, args);
	}

}
