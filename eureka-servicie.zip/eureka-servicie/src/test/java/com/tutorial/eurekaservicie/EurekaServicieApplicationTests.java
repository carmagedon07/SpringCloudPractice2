package com.tutorial.eurekaservicie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServicieApplicationTests {

	@Test
	void contextLoads() {
	}

}
